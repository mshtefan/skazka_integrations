window._CONFIG = {

  SAILPLAY: {
    partner_id: 1569,
    domain: 'http://sailplay.ru',
    lang: 'ru'
  },
  social_styles: 'http://saike.ru/sailplay/integration/jeweler/profile/dist/css/social_styles.css'

};
//
//var _klooker_config = {
//
//  partner_id: 1188,
//  domain: 'http://skazka.loc',
//  social_styles: 'https://www.hidden.klooker.nl/loyalty/dist/css/klooker_social.css'
//
//};