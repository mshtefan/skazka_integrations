window._CONFIG = {

  SAILPLAY: {
    partner_id: 1569,
    domain: 'https://sailplay.ru'
  },
  social_styles: 'https://sailplay.ru/_integrations/jeweler/profile/dist/css/social_styles.css'

};