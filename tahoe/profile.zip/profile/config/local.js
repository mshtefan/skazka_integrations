window._CONFIG = {

  SAILPLAY: {
    partner_id: 1571,
    domain: 'http://sailplay.net',
    lang: 'en'
  },
  social_styles: 'http://saike.ru/sailplay/integration/tahoe/profile/dist/css/social_styles.css'

};
//
//var _klooker_config = {
//
//  partner_id: 1188,
//  domain: 'http://skazka.loc',
//  social_styles: 'https://www.hidden.klooker.nl/loyalty/dist/css/klooker_social.css'
//
//};