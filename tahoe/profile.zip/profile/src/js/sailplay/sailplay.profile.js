(function () {

  angular.module('sailplay.profile', [])

    /**
     * @ngdoc directive
     * @name sailplay.profile.directive:sailplayProfile
     * @scope
     * @restrict A
     *
     * @description
     * SailPlay profile directive used for rendering user's profile. =)
     *
     */
    .directive('sailplayProfile', function(SailPlayApi, SailPlay){

      return {

        restrict: 'A',
        replace: false,
        scope: true,
        link: function(scope){

          /**
           * @ngdoc method
           * @name user
           * @methodOf sailplay.profile.directive:sailplayProfile
           * @description
           * Returns user's data stored in API service with key: 'load.user.info'
           *
           * @returns {Object} User's profile data
           */
          scope.user = SailPlayApi.data('load.user.info');

          /**
           * @ngdoc method
           * @name logout
           * @methodOf sailplay.profile.directive:sailplayProfile
           * @description
           * Logout current user, clear session cookies
           */
          scope.logout = function(){

            SailPlay.send('logout');

          };

        }

      };

    });

}());
