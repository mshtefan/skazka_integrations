(function () {

  angular.module('sailplay.widgets', [ 'core', 'ui', 'sailplay', 'templates' ])

    .config(function(SailPlayProvider, SailPlayActionsDataProvider, SailPlayBadgesProvider){

      //possible values:
      //url,cookie,remote
      SailPlayProvider.set_auth_type('remote');
      SailPlayProvider.set_remote_config({

      });

      SailPlayProvider.set_cookie_name('auth_hash');

      _CONFIG && SailPlayProvider.set_config({
        partner_id: _CONFIG.SAILPLAY.partner_id,
        domain: _CONFIG.SAILPLAY.domain,
        lang: _CONFIG.SAILPLAY.lang
      });

      _LOCALE && SailPlayActionsDataProvider.set_actions_data(_LOCALE.actions);

      SailPlayBadgesProvider.set_limits([ 0, 5000 ]);

    })

    .run(function($rootScope, SailPlay){

      $rootScope.locale = _LOCALE || {};

      $rootScope.$on('sailplay-init-success', function(){
        console.log('auth!');
        //SailPlay.authorize();

      });

    })

    .controller('RemoteLoginConfig', function($scope){

      $scope.remote_login_options = {
        background: 'transparent',
        disabled_options: ['socials', 'agreement'],
        texts: {
          ok: 'OK',
            back: 'BACK',
            forgot_password: 'Get password',
            login: 'LOGIN/SIGN UP',
            password_placeholder: 'Enter your password',
            sms_placeholder: 'SMS-code',
            new_pass_placeholder: 'Enter new password',
            new_pass_placeholder2: 'Repeat new password',
            exist: 'LOG OUT',
            cancel: 'CANCEL',
            name_placeholder: 'You are already logged in as a',
            auth_text: 'You are logged',
            auth_text_how: 'in as'
        }

      };

    })

    .controller('CompaniesList', function($scope, $http){

      $scope.companies = [];

      $http.get('config/companies.json').then(function(res){

        $scope.companies = res.data;
        console.dir($scope.companies);

      });

    })

    .directive('sailplayWidgets', function(SailPlay, ipCookie, SailPlayApi, $document){

      return {
        restrict: 'E',
        replace: true,
        scope: true,
        templateUrl: '/html/app.html',
        link: function(scope){

          scope.show_history = false;

          scope.show_statuses_list = false;

          scope.show_profile_info = false;

          scope.show_profile_action = true;

          scope.show_login = false;

          scope.show_companies = false;

          scope.$on('sailplay-login-cancel', function(){
            scope.show_login = false;
          });

          scope.$on('sailplay-login-success', function(){
            scope.show_login = false;
          });

          scope.$on('sailplay-logout-success', function(){

            SailPlayApi.reset();

          });

          scope.fill_profile = function(){

            scope.show_profile_info = true;

          };

          scope.body_lock = function(state){

            if(state) {
              $document[0].body.classList.add('body_lock');
            }
            else {
              $document[0].body.classList.remove('body_lock');
            }

          };

          scope.close_profile = function(){

            //scope.show_profile_action = false;

            scope.show_profile_info = false;

            scope.body_lock(false);

          };

          scope.open_profile = function(){
            scope.show_profile_info = true;
            scope.body_lock(true);
          };

          SailPlay.on('tags.exist.success', function(res){

            if(res.status === 'ok' && res.tags[0].exist) {

              scope.show_profile_action = false;
              scope.$apply();

            }

          });

          //scope.hide_hist = ipCookie('profile_form') && ipCookie('profile_form').custom_vars.hide_hist === 'Да';

        }
      }

    });

  window.addEventListener('DOMContentLoaded', function(){

    var app_container = document.getElementsByTagName('sailplay-widgets')[0];

    app_container && angular.bootstrap(app_container, [ 'sailplay.widgets' ]);

  });

}());
